package ObjetoGeometrico;

public class objetoGeometrico {
	public double area;
	protected double perimetro;
	protected String cor;
	
	public String getCor ( ) {
		return cor;
	}
	
	public void setCor (String c) {
		cor = c;
	}

}
