# ObjetoGeometrico
 Projeto para criar objetos geometricos e saber a area e perimetros de cada um. Projeto foi criado encima do paradigma de orientação a objetos
